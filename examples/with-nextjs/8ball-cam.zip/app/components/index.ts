export { ImageCaptureDialogMobile } from "./image-capture-dialog-mobile";
export { ImageCaptureDialogDesktop } from "./image-capture-dialog-desktop";
