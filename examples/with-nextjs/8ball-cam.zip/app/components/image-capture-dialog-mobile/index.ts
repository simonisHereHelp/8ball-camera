export * from "./image-capture-dialog-mobile";
