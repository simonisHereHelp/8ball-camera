// app/api/auth/[...nextauth]/route.js
export { GET, POST } from "@/auth";
