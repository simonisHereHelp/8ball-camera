export interface IssuerCanonEntry {
  master: string;
  aliases?: string[];
  description?: string;
}
